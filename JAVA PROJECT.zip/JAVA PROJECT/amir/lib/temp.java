import javax.swing.*;
class temp extends  JFrame
{
   public temp()
   {

      setTitle("abc");
      setLayout(null);
      setSize(400, 300);
      setVisible(true);
      
   }

    public static void main(String[] agrs)
    {
        new temp();
    } 
}